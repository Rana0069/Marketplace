const { getDb } = require('./src/db');

async function seed() {
  const db = await getDb();

  // 🔥 Delete old products first
  await db.run("DELETE FROM products");

  console.log("Old products deleted");


  const products = [
    {
      title: "iPhone 15",
      price: 999,
      description: "Brand new iPhone",
      images: ["/images/iphone15.png", "/images/laptop.png"]
    },
    {
      title: "Gaming Laptop",
      price: 1200,
      description: "RTX 3060 laptop",
      images: ["/images/laptop.png", "/images/iphone15.png", "/images/mortalgandu.jpg"]
    },
    {
      title: "GEFORCE RTXX 6090 TI (Premium Edition)",
      price: 150,
      description: "Brand new RTX GAYFORCE RTXX 6090 with 320GB GayRAM 6.9 DLLA and 100% Technology",
      images: ["/images/RTX6090.jpg"]
    },

  ];

  for (const product of products) {
    await db.run(
      `INSERT INTO products (title, price, description, image, images)
       VALUES (?, ?, ?, ?, ?)`,
      [
        product.title,
        product.price,
        product.description,
        product.images[0],
        JSON.stringify(product.images)
      ]
    );
  }

  console.log("Seeding complete!");
}

seed();
