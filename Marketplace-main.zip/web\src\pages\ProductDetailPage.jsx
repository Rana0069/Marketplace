import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api';

export default function ProductDetailPage() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [selectedImage, setSelectedImage] = useState('');

  useEffect(() => {
    api.get(`/products/${id}`).then(({ data }) => {
      setProduct(data);
      const defaultImage = data.images?.[0] || data.image || '';
      setSelectedImage(defaultImage);
    });
  }, [id]);

  if (!product) return <p className="container">Loading...</p>;

  const galleryImages = product.images?.length ? product.images : [product.image].filter(Boolean);
  const imageToShow = selectedImage || galleryImages[0];

  const resolveImage = (imagePath) => {
    if (!imagePath) return 'https://via.placeholder.com/800x600?text=No+Image';
    return imagePath.startsWith('http') ? imagePath : `http://localhost:4000${imagePath}`;
  };

  return (
    <main className="container detail">
      <div className="detail-gallery">
        <img
          src={resolveImage(imageToShow)}
          alt={product.title}
        />
        {galleryImages.length > 1 && (
          <div className="thumbnail-row">
            {galleryImages.map((img, index) => (
              <button
                key={`${img}-${index}`}
                type="button"
                className={`thumb-btn ${imageToShow === img ? 'active' : ''}`}
                onClick={() => setSelectedImage(img)}
              >
                <img src={resolveImage(img)} alt={`${product.title} ${index + 1}`} />
              </button>
            ))}
          </div>
        )}
      </div>

      <div>
        <h1>{product.title}</h1>
        <p className="price">${product.price.toFixed(2)}</p>
        <p>{product.description}</p>
      </div>
    </main>
  );
}
